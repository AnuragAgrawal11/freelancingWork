% this process may be repeated for each network i. 
% presently we only use MLP with BPA as the architecture with different parameters. different modules may have different models
i=3;

% network initialization
nets{i}=newff(minmax(in'),[20,1],{'tansig','purelin'},'traingd');
nets{i}.trainParam.show = 50;
nets{i}.trainParam.lr = 0.05;
nets{i}.trainParam.mc = 0.7;
nets{i}.trainParam.epochs = 3500;
nets{i}.trainParam.goal = 1e-2;

% training
[nets{i},tr]=train(nets{i},trainInput',trainOutput');

% testing on training data with a single module. 
% this is for the setting of parameters such that the individual performance is maximized 
a = sim(nets{i},trainInput');
a=a';
corr=0;
for j=1:size(trainInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if trainOutput(j)==ans corr=corr+1; end
end

corr 
corr/size(trainInput,1)*100 % percent train accuracy

% testing on testing data
a = sim(nets{i},testInput');
a=a';
corr=0;
for j=1:size(testInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if testOutput(j)==ans corr=corr+1; end
end

corr
corr/size(testInput,1)*100 % percent test accuracy