% find accuracy for training data
corr=0;
for i=1:size(trainInput,1)
    %solve by each module and take mean
    ans=0;
    for j=1:nmods
        a = sim(nets{j},trainInput(i,:)');
        a=a';
        ans=ans+a(1);
    end
    ans=ans/nmods;
    if ans<0.5 ans=0; else ans=1; end
    if trainOutput(i)==ans corr=corr+1; end
end
corr
corr/size(trainInput,1)*100 % percent train accuracy

% find accuracy for testing data
corr=0;
for i=1:size(testInput,1)
    %solve by each module and take mean
    ans=0;
    for j=1:nmods
        a = sim(nets{j},testInput(i,:)');
        a=a';
        ans=ans+a(1);
    end
    ans=ans/nmods;
    if ans<0.5 ans=0; else ans=1; end
    if testOutput(i)==ans corr=corr+1; end
end
corr
corr/size(testInput,1)*100 % percent test accuracy