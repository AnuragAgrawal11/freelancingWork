a=newfis('fuz');
a.input(1).name='inp1';
a.input(1).range=[0 1];
a.input(1).mf(1).name='low';
a.input(1).mf(1).type='gaussmf';
a.input(1).mf(1).params=[0.1699 0];
a.input(1).mf(2).name='med';
a.input(1).mf(2).type='gaussmf';
a.input(1).mf(2).params=[0.1699 0.5];
a.input(1).mf(3).name='high';
a.input(1).mf(3).type='gaussmf';
a.input(1).mf(3).params=[0.1699 1];

a.input(2).name='inp2';
a.input(2).range=[0 1];
a.input(2).mf(1).name='low';
a.input(2).mf(1).type='gaussmf';
a.input(2).mf(1).params=[0.1699 0];
a.input(2).mf(2).name='med';
a.input(2).mf(2).type='gaussmf';
a.input(2).mf(2).params=[0.1699 0.5];
a.input(2).mf(3).name='high';
a.input(2).mf(3).type='gaussmf';
a.input(2).mf(3).params=[0.1699 1];

a.output(1).name='out';
a.output(1).range=[0 1];
a.output(1).mf(1).name='cheap';
a.output(1).mf(1).type='trimf';
a.output(1).mf(1).params=[-0.5 0 0.5];
a.output(1).mf(2).name='med';
a.output(1).mf(2).type='trimf';
a.output(1).mf(2).params=[0 0.5 1];
a.output(1).mf(3).name='exp';
a.output(1).mf(3).type='trimf';
a.output(1).mf(3).params=[0.5 1 1.5];

a.rule(1).antecedent=[1 3];
a.rule(1).consequent=[1];
a.rule(1).weight=1;
a.rule(1).connection=2;

a.rule(2).antecedent=[2 2];
a.rule(2).consequent=[2];
a.rule(2).weight=1;
a.rule(2).connection=2;
a.rule(3).antecedent=[3 1];
a.rule(3).consequent=[3];
a.rule(3).weight=1;
a.rule(3).connection=2;

evalfis([0.1 0.2], a)