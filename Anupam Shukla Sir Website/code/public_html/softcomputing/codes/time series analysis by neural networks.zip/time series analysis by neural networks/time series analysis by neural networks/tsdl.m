% p=[];
% t=[];
% for j=15:200
%     p=[p;i(j-13) i(j-12) i(j-1)];
%     t=[t;i(j)];
% end
% p=p';t=t';
% p=log(p);t=log(t);
% net=newff(minmax(p),[20 1],{'tansig','tansig'} ,'traingdm');
% net.trainParam.show = 50;
% net.trainParam.lr = 0.1;
% net.trainParam.mc = .01;
% net.trainParam.epochs = 2500;
% net.trainParam.goal = 0.01;
% [net,tr]=train(net,p,t);
% p=[];
% for j=15:388
%     p=[p;i(j-13) i(j-12) i(j-1)];
% end
% p=p';
% p=log(p);
% t1=sim(net,p);
% t1=exp(t1);
% t1=[i(1) i(2) i(3) i(4) i(5) i(6) i(7) i(8) i(9) i(10) i(11) i(12) i(13) i(14) t1];
plot(1:388,i','-*',1:388,t1,'-o');
Legend('Original Series','Generated Series');
xLabel='Time';
yLabel='Series Value';
