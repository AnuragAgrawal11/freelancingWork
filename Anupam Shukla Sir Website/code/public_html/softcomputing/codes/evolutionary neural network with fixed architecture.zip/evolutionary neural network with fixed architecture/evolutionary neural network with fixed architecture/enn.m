function fit=enn(X)

global trainInput trainOutput; 

in=30; %number of input layer neurons
hn=18; %number of hidden layer neurons

% network initialization
net=newff(minmax(trainInput'),[hn,1],{'tansig','purelin'},'traingd');

c=1; %counter for the GA individual genes

%set input to hidden layer weights
for i=1:hn
    for j=1:in
        net.IW{1}(i,j)=X(c);c=c+1;
    end
end

%set hidden layer to output weights
for i=1:hn
    net.LW{2}(i)=X(c);c=c+1;
end

%set hidden layer neuron biases
for i=1:hn
    net.b{1}(i)=X(c);c=c+1;
end

%set output layer neuron bias
net.b{2}(1)=X(c);c=c+1;

% training as local search strategy
net.trainParam.show = NaN;
net.trainParam.lr = 0.05;
net.trainParam.mc = 0.1;
net.trainParam.epochs = 30;
net.trainParam.goal = 1e-2;
[net,tr]=train(net,trainInput',trainOutput');

% testing on training data as a measure of fitness  
a = sim(net,trainInput');
a=a';
corr=0;
for j=1:size(trainInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if trainOutput(j)==ans corr=corr+1; end
end
corr;
size(trainInput,1);
fit=-corr/size(trainInput,1)*100; % percent train accuracy as fitness

%note that the number of variables in GA are:
%Weights(input to hidden): hn*in
%Weights(hidden to output): hn*1
%Biases(hidden): hn
%Biases(output): 1

% Total: hn*in+hn*1+hn+1
% all usually lie within -2 to 2