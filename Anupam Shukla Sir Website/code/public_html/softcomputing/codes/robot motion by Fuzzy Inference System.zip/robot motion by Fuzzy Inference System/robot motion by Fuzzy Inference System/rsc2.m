% Motion of Robot by Fuzzy Infrence System
a = readfis('rsc');

% Initial Configuration
i=70; 
j=30;
an=pi+pi/2;
s=[];
g=100;
div=100;
% Final Position
fi=30;
fj=70;
while true
        s=[s;i j an];
        if i>=fi-5 && i<=fi+5 && j>=fi-5 && j<=fj+5
            break;
        end
        in1=atan2(fi-i,fj-j)-an;
        if in1>pi
            in1=2*pi-in1;
        end
        if in1<-pi
            in1=2*pi+in1;
        end
        in4=sqrt((fi-i)*(fi-i)+(fj-j)*(fj-j))/(sqrt(2)*div);
        if in4>1
            in4=1;
        end
%         in1*180/(2*pi) 
%         in2 
%         in3 
%         in4
        an2=evalfis([in1*180/pi in4], a)*pi/180;
%         if an2>maxcurve
%             maxcurve=an2;
%         end
        an=an+an2;
        if an>pi
            an=2*pi-an
        end
        if an2<-pi
            an2=2*pi+an2;
        end
        i=i+sin(an);
        j=j+cos(an);
end
     plot(s(:,1),s(:,2))
     set(gca,'XTick',0:10:100)
     set(gca,'YTick',0:10:100)
     axis([1 100 1 100]); 