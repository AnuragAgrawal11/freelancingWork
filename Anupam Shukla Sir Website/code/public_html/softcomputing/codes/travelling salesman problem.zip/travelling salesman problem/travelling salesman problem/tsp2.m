% this is the function to plot the path. 
% cp stores the node locations. results of GA are stored in x
cp=[            438   154
   214   231
   354   415
    35   150
    10   355
   254    37
   435   375
   399   234
   400   472
    98     7
   357    27
   108   369
   393   318
    86   465
   103   230
   232   256
    37   212
   298   208
    95   194
   467   428];
     ci=zeros(1,20);
     fg=0;
     y=[];
     for i=1:20
         if int32(x(i))<=20 && int32(x(i))>=1
            y=[y int32(x(i))];
         elseif int32(x(i))>20
            y=[y 20];
         else
             y=[y 1];
         end
                 
     end
     for i=1:20
         if ci(y(i))==1
             for j=1:20
                 if ci(j)==0
                     ci(j)=1;
                     y(i)=j;
                     break;
                 end
             end
         else
             ci(y(i))=1;
         end
     end
     a=250;
     b=250;
     s=0;
     r=[];
     if fg==1
         fit=Inf;
     else
         for i=1:20
             s=s+sqrt((a-cp(y(i),1))*(a-cp(y(i),1))+(b-cp(y(i),2))*(b-cp(y(i),2)));
             a=cp(y(i),1);b=cp(y(i),2);
             r=[r;cp(y(i),1) cp(y(i),2)];
         end
         s=s+sqrt((a-250)*(a-250)+(b-250)*(b-250));
         fit=s;
     end
     r=[250 250;r;250 250];
     plot(r(:,1),r(:,2))
     