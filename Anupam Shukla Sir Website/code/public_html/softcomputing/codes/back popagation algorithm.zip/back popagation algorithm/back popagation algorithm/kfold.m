meanTrain=0; %mean performacne of training data
meanTest=0; %mean performacne of testing data

% variable 'dataset' contains the complete data which may be easily imported 
% we assume the first column contains the outputs with 0 and 1 denoting the two classes
% all other columns denote inputs
in=dataset(:,2:31); %in contains all inputs
ou=dataset(:,1:1); %ou contains all outputs

% normalization of all inputs by simply dividing by maximum value
for i=1:size(in,2)
    in(:,i)=in(:,i)/max(in(:,i));
end

% division of inputs and outputs in k-folds
k=10; % no of folds
inputs=cell(k,1);
outputs=cell(k,1);

for i=1:size(in,1)
    f=floor(rand*k+1);
    inputs{f}=[inputs{f};in(i,:)];
    outputs{f}=[outputs{f};ou(i,:)];
end

for i=1:k
    % network initialization 
    net=newff(minmax(in'),[18,1],{'tansig','purelin'},'traingd');
    net.trainParam.show = 50;
    net.trainParam.lr = 0.05;
    net.trainParam.mc = 0.7;
    net.trainParam.epochs = 3500;
    net.trainParam.goal = 1e-2;
    
    % training with 'i'th data set
    [net,tr]=train(net,inputs{i}',outputs{i}');
    
    % testing on testing data
    a = sim(net,inputs{i}');
    a=a';
    corr=0;
    for j=1:size(inputs{i},1)
        if a(j)<0.5 ans=0; else ans=1; end
        if outputs{i}(j)==ans corr=corr+1; end
    end
    
    corr
    meanTrain=meanTrain+corr;
    corr/size(inputs{i},1)*100 % percent train accuracy    
    
    % testing on other k-1 sets
    for j=1:k
        if j==i continue; end
        a = sim(net,inputs{j}');
        a=a';
        corr=0;
        for l=1:size(inputs{j},1)
            if a(l)<0.5
                ans=0;
            else
                ans=1;
            end
            if outputs{j}(l)==ans
                corr=corr+1;
            end
        end

        corr 
        corr/size(inputs{j},1)*100 % percent test accuracy on 'j'th data set 
        meanTest=meanTest+corr;
    end
end

meanTrain
meanTrain/size(in,1)*100 % mean percent train accuracy. Each item in dataset is tested once

meanTest
meanTest/(size(in,1)*(k-1))*100 % mean percent test accuracy. Each item in dataset is tested k-1 times
