% find accuracy for training data
corr=0;
for i=1:size(trainInput,1)
    %find cluster for the ith training input
    cn=1;
    for l=2:nclus
        if norm(trainInput(j)-centers(l)) < norm(trainInput(j)-centers(cn))
            cn=l;
        end
    end
    
    % find output by respective module
    a = sim(nets{cn},trainInput(i,:)');
    a=a';
    if a(1)<0.5 ans=0; else ans=1; end
    if trainOutput(i)==ans corr=corr+1; end
end
corr
corr/size(trainInput,1)*100 % percent train accuracy

% find accuracy for testing data
corr=0;
for i=1:size(testInput,1)
    %find cluster for the ith test input
    cn=1;
    for l=2:nclus
        if norm(testInput(j)-centers(l)) < norm(testInput(j)-centers(cn))
            cn=l;
        end
    end
    
    % find output by respective module
    a = sim(nets{cn},testInput(i,:)');
    a=a';
    if a(1)<0.5 ans=0; else ans=1; end
    if testOutput(i)==ans corr=corr+1; end
end
corr
corr/size(testInput,1)*100 % percent test accuracy
    