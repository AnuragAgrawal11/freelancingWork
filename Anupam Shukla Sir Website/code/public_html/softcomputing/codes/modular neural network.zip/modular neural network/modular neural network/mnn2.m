% this process may be repeated for each network i
i=3;
% network initialization
nets{i}=newff(minmax(in'),[18,1],{'tansig','purelin'},'traingd');
nets{i}.trainParam.show = 50;
nets{i}.trainParam.lr = 0.05;
nets{i}.trainParam.mc = 0.7;
nets{i}.trainParam.epochs = 3500;
nets{i}.trainParam.goal = 1e-2;

% training
[nets{i},tr]=train(nets{i},trainInput1{i}',trainOutput1{i}');

% testing on training data with a single module. 
% this is only for the setting of parameters such that the individual performance is maximized 
a = sim(nets{i},trainInput1{i}');
a=a';
corr=0;
for j=1:size(trainInput1{i},1)
    if a(j)<0.5 ans=0; else ans=1; end
    if trainOutput1{i}(j)==ans corr=corr+1; end
end

corr 
corr/size(trainInput1{i},1)*100 % percent train accuracy

% testing on testing data
a = sim(nets{i},testInput1{i}');
a=a';
corr=0;
for j=1:size(testInput1{i},1)
    if a(j)<0.5 ans=0; else ans=1; end
    if testOutput1{i}(j)==ans corr=corr+1; end
end

corr
corr/size(testInput1{i},1)*100 % percent test accuracy