<?php
if ($_GET['randomId'] != "h84E1WnPjE1bk93lS3dv5gsvkEoLL4FroeEdtBGgrArYf84sMYgK_d4h6kSivxok") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
