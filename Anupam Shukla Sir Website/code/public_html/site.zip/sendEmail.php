﻿<li>Please enter your name</li> 
<li>Please enter a valid email address</li> 
<li>Please leave a comment.</li>