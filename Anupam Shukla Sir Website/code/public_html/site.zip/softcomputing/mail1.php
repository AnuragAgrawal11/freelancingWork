        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html xmlns="http://www.w3.org/1999/xhtml">

<head PROFILE="../../../../gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Real Life Applications of Soft Computing</title><meta name="keywords" content="Real Life Application of Soft Computing, real life application of soft computing," /><meta name="keywords" content="Real Life Application of Soft Computing, real life application of soft computing," />

<!-- begin style -->

<link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<link rel="stylesheet" href="style/background-light.css" type="text/css" media="screen" />

<link rel="stylesheet" href="style/colors-grey.css" type="text/css" media="screen" />

<!-- styles the twitter panel -->
<link rel="stylesheet" type="text/css" href="js/jquery.twitter.css" media="screen" />
</head>

<body>
<script type="text/javascript" language="javascript" src="scriptaculous/lib/prototype.js"></script> 
<script type="text/javascript" language="javascript" src="scriptaculous/src/scriptaculous.js"></script> 
<script type="text/javascript" language="javascript" src="jsvalidate.js"></script>
<link rel="stylesheet" type="text/css" 
href="ssc.css">
      <div id="footer">
        <div class="widget">
                
                    <div class="header">
                
                        <div align="justify"><img src="images/55.jpg" alt="Links" height="155" /></div>
                    </div>
                    
                    <div class="content" id="quickcontact">
                    
                        <form name="quickcontact" action="mail.php?url=contact.php" method="post">
						
							<label for="name" id="name_label">
							Name
						  </label>
						  <div align="justify">
							   
							
							    <input type="text" name="name" id="name" class="jsrequired"/>
						      <br />							
							  
						        <label for="email" id="email_label">
							Email
							</label>
							<label class="error" for="email" id="email_error">
							
							</label>
							<input type="text" name="email" id="email" class="jsrequired" />
							<br />
							  
						   
							Message
							</label>
														<br />
						    <textarea rows="15" cols="50" name="message" id="message" class="jsrequired"></textarea>
						  </div>
							
                            
                           
                                                 
                            <div class="floatleft">							
								
							  <div align="justify">
							    <input type="submit">                          
						      </div>
                            </div>
						</form>
                    </div>
                </div>
                
                <div align="center">
                                  
                </div>
               
                <div class="clearer">&nbsp;</div>			
	  </div>

	
</body>
</html>