<?php
if ($_GET['randomId'] != "NzXubiXUD6exc4iJc3dTVNR5bgPj39RqbG8EUsoE1aHu7l2UnxmRocqctuJxDWsq") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
