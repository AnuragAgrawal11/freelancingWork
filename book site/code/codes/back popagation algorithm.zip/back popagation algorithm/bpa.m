co=1; % Testing takes pleace for co number of runs and average is returned 
meanTrain=0; %mean performacne of training data
meanTest=0; %mean performacne of testing data

% variable 'dataset' contains the complete data which may be easily imported 
% we assume the first column contains the outputs with 0 and 1 denoting the two classes
% all other columns denote inputs
in=dataset(:,1:8); %in contains all inputs
ou=dataset(:,9:9); %ou contains all outputs

% normalization of all inputs by simply dividing by maximum value
for i=1:size(in,2)
    in(:,i)=in(:,i)/max(in(:,i));
end

for i=1:co
    
    % division of inputs and outputs in training and testing data
    trainInput=[];
    trainOutput=[];

    testInput=[];
    testOutput=[];

    for j=1:size(in,1)
        if rand<.7 % Let 70% data be for training and 30% for testing
            trainInput=[trainInput;in(j,:)];
            trainOutput=[trainOutput;ou(j)];
        else
            testInput=[testInput;in(j,:)];
            testOutput=[testOutput;ou(j)];
        end
    end

    % network initialization
    net=newff(minmax(in'),[18,1],{'tansig','purelin'},'traingd');
    net.trainParam.show = 50;
    net.trainParam.lr = 0.05;
    net.trainParam.mc = 0.7;
    net.trainParam.epochs = 3500;
    net.trainParam.goal = 1e-2;
    
    % training
    [net,tr]=train(net,trainInput',trainOutput');

    % testing on training data
    a = sim(net,trainInput');
    a=a';
    corr=0;
    for j=1:size(trainInput,1)
        if a(j)<0.5 ans=0; else ans=1; end
        if trainOutput(j)==ans corr=corr+1; end
    end

    corr 
    corr/size(trainInput,1)*100 % percent train accuracy
    meanTrain=meanTrain+corr;

    % testing on testing data
    a = sim(net,testInput');
    a=a';
    corr=0;
    for j=1:size(testInput,1)
        if a(j)<0.5 ans=0; else ans=1; end
        if testOutput(j)==ans corr=corr+1; end
    end

    corr
    meanTest=meanTest+corr;
    corr/size(testInput,1)*100 % percent test accuracy
end

s=size(trainInput,1);
meanTrain/co
(meanTrain/co)/s*100 % mean percent train accuracy

s=size(testInput,1);
meanTest/co
(meanTest/co)/s*100 % mean percent test accuracy
