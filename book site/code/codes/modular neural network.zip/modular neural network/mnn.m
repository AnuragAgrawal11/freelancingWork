% variable 'dataset' contains the complete data which may be easily imported 
% we assume the first column contains the outputs with 0 and 1 denoting the two classes
% all other columns denote inputs
in=dataset(:,2:31); %in contains all inputs
ou=dataset(:,1:1); %ou contains all outputs

% normalization of all inputs by simply dividing by maximum value
for i=1:size(in,2)
    in(:,i)=in(:,i)/max(in(:,i));
end

% division of inputs and outputs in training and testing data
trainInput=[];
trainOutput=[];

testInput=[];
testOutput=[];

for j=1:size(in,1)
    if rand<.7 % Let 70% data be for training and 30% for testing
        trainInput=[trainInput;in(j,:)];
        trainOutput=[trainOutput;ou(j)];
    else
        testInput=[testInput;in(j,:)];
        testOutput=[testOutput;ou(j)];
    end
end
    
% cluster using the training data using Fuzzy C Means Clustering and get cluster centers
nclus=3; %number of clusters to be formed
centers = fcm(trainInput,nclus);

trainInput1=cell(nclus,1);
trainOutput1=cell(nclus,1);
testInput1=cell(nclus,1);
testOutput1=cell(nclus,1);
    
for j=1:size(trainInput,1)
    cn=1;
    for l=2:nclus
        if norm(trainInput(j)-centers(l)) < norm(trainInput(j)-centers(cn))
            cn=l;
        end
    end
    trainInput1{cn}=[trainInput1{cn};trainInput(j,:)]; 
    trainOutput1{cn}=[trainOutput1{cn};trainOutput(j,:)];
end
    
for j=1:size(testInput,1)
    cn=1;
    for l=2:nclus
        if norm(testInput(j)-centers(l)) < norm(testInput(j)-centers(cn))
            cn=l;
        end
    end
    testInput1{cn}=[testInput1{cn};testInput(j,:)]; 
    testOutput1{cn}=[testOutput1{cn};testOutput(j,:)];
end

nets=cell(nclus,1);