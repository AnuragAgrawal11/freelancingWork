X=garesults.x;

in=30; %number of input layer neurons
hn=18; %number of hidden layer neurons

% network initialization
net=newff(minmax(trainInput'),[hn,1],{'tansig','purelin'},'traingd');

c=1; %counter for the GA individual genes

%set input to hidden layer weights
for i=1:hn
    for j=1:in
        net.IW{1}(i,j)=X(c);c=c+1;
    end
end

%set hidden layer to output weights
for i=1:hn
    net.LW{2}(i)=X(c);c=c+1;
end

%set hidden layer neuron biases
for i=1:hn
    net.b{1}(i)=X(c);c=c+1;
end

%set output layer neuron bias
net.b{2}(1)=X(c);c=c+1;

% training as local search strategy
net.trainParam.show = NaN;
net.trainParam.lr = 0.05;
net.trainParam.mc = 0.1;
net.trainParam.epochs = 30;
net.trainParam.goal = 1e-2;
[net,tr]=train(net,trainInput',trainOutput');

% testing on training data 
a = sim(net,trainInput');
a=a';
corr=0;
for j=1:size(trainInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if trainOutput(j)==ans corr=corr+1; end
end
corr
size(trainInput,1)
corr/size(trainInput,1)*100 % percent train accuracy 

% testing on testing data 
a = sim(net,testInput');
a=a';
corr=0;
for j=1:size(testInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if testOutput(j)==ans corr=corr+1; end
end
corr/size(testInput,1)*100 % percent test accuracy