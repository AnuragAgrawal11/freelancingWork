% variable 'dataset' contains the complete data which may be easily imported 
% we assume the first column contains the outputs with 0 and 1 denoting the two classes
% all other columns denote inputs

global trainInput trainOutput

in=dataset(:,2:31); %in contains all inputs
ou=dataset(:,1:1); %ou contains all outputs

% normalization of all inputs by simply dividing by maximum value
for i=1:size(in,2)
    in(:,i)=in(:,i)/max(in(:,i));
end

% division of inputs and outputs in training and testing data
trainInput=[];
trainOutput=[];

testInput=[];
testOutput=[];

for j=1:size(in,1)
    if rand<.7 % Let 70% data be for training and 30% for testing
        trainInput=[trainInput;in(j,:)];
        trainOutput=[trainOutput;ou(j)];
    else
        testInput=[testInput;in(j,:)];
        testOutput=[testOutput;ou(j)];
    end
end