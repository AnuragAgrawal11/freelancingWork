a=[
    0 0 0 1 0 0 
    0 0 1 0 1 0 
    0 1 0 0 0 1 
    0 1 1 1 1 1
    0 1 0 0 0 1
    1 0 0 0 0 1
    ];

b=[
    1 1 1 1 1 0 
    1 0 0 0 0 1 
    1 1 1 1 1 0 
    1 0 0 0 1 0
    1 0 0 0 0 1
    1 1 1 1 1 0
    ];

c=[
    1 1 1 1 1 1 
    1 0 0 0 0 0 
    1 0 0 0 0 0 
    1 0 0 0 0 0
    1 0 0 0 0 0
    1 1 1 1 1 1
    ];

d=[
    1 1 1 1 0 0 
    1 0 0 0 1 0 
    1 0 0 0 0 1 
    1 0 0 0 0 1
    1 0 0 0 1 0
    1 1 1 1 0 0
    ];

e=[
    1 1 1 1 1 1 
    1 0 0 0 0 0 
    1 1 1 1 1 1 
    1 0 0 0 0 0
    1 0 0 0 0 0
    1 1 1 1 1 1
    ];

f=[
    1 1 1 1 1 1 
    1 0 0 0 0 0 
    1 1 1 1 1 1 
    1 0 0 0 0 0
    1 0 0 0 0 0
    1 0 0 0 0 0
    ];

g=[
    1 1 1 1 1 1 
    1 0 0 0 0 0 
    1 0 0 0 0 0 
    1 0 1 1 1 1
    1 0 0 0 0 1
    1 1 1 1 1 0
    ];

h=[
    1 0 0 0 0 1 
    1 0 0 0 0 1 
    1 0 0 0 0 1 
    1 1 1 1 1 1
    1 0 0 0 0 1
    1 0 0 0 0 1
    ];

i0=[
    1 1 1 1 1 1 
    0 0 0 1 0 0 
    0 0 0 1 0 0 
    0 0 0 1 0 0
    0 0 0 1 0 0
    1 1 1 1 1 1
    ];

j0=[
    1 1 1 1 1 1 
    0 0 0 1 0 0 
    0 0 0 1 0 0 
    1 0 0 1 0 0
    1 0 0 1 0 0
    0 1 1 0 0 0
    ];

a1=[];
for i=1:6
    for j=1:6
        a1=[a1;a(i,j)];
    end
end

b1=[];
for i=1:6
    for j=1:6
        b1=[b1;b(i,j)];
    end
end

c1=[];
for i=1:6
    for j=1:6
        c1=[c1;c(i,j)];
    end
end

d1=[];
for i=1:6
    for j=1:6
        d1=[d1;d(i,j)];
    end
end

e1=[];
for i=1:6
    for j=1:6
        e1=[e1;e(i,j)];
    end
end

f1=[];
for i=1:6
    for j=1:6
        f1=[f1;f(i,j)];
    end
end

g1=[];
for i=1:6
    for j=1:6
        g1=[g1;g(i,j)];
    end
end

h1=[];
for i=1:6
    for j=1:6
        h1=[h1;h(i,j)];
    end
end

i1=[];
for i=1:6
    for j=1:6
        i1=[i1;i0(i,j)];
    end
end

j1=[];
for i=1:6
    for j=1:6
        j1=[j1;j0(i,j)];
    end
end
le=[a1 b1 c1 d1 e1 f1 g1 h1 i1 j1];
t=eye(10);
net = newrb(le,t,0.1,15);
o=sim(net,le);
cor=0;
for i=1:10
    max=-1;mp=0;
    for j=1:10
        if(o(j,i)>max) 
            max=o(j,i);mp=j; 
        end
        if Y(i)==i
            cor=cor+1;
        end
    end
end
cor
% for testing
a=[
    0 0 0 1 0 0 
    0 0 1 0 1 0 
    0 1 0 0 0 1 
    0 1 1 1 0 0
    0 1 0 0 0 1
    1 0 0 0 0 1
    ];

a1=[];
for i=1:6
    for j=1:6
        a1=[a1;a(i,j)];
    end
end

le=[a1];
a2=sim(net,le);
a2