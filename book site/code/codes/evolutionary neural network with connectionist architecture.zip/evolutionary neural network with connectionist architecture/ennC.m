function fit=enn(X)

global trainInput trainOutput; 
ALPHA = 0.01; %connection penalty
in=30; %number of input layer neurons
hn=30; %number of hidden layer neurons

% network initialization
net=newff(minmax(trainInput'),[hn,1],{'tansig','purelin'},'traingd');

c=1; %counter for the GA individual genes
nc=0;%number of connections counter

%set input to hidden layer weights
for i=1:hn
    for j=1:in
        con=X(c);c=c+1;
        if(con<0) net.IW{1}(i,j)=0; else net.IW{1}(i,j)=X(c);nc=nc+1; end
        c=c+1;
    end
end

%set hidden layer to output weights
for i=1:hn
    con=X(c);c=c+1;
    if(con<0) net.LW{2}(i)=0; else net.LW{2}(i)=X(c);nc=nc+1; end
    c=c+1;
end

%set hidden layer neuron biases
for i=1:hn
    net.b{1}(i)=X(c);c=c+1;
end

%set output layer neuron bias
net.b{2}(1)=X(c);c=c+1;

% training as local search strategy
net.trainParam.show = NaN;
net.trainParam.lr = 0.05;
net.trainParam.mc = 0.1;
net.trainParam.epochs = 30;
net.trainParam.goal = 1e-2;
[net,tr]=train(net,trainInput',trainOutput');

% testing on training data as a measure of fitness  
a = sim(net,trainInput');
a=a';
corr=0;
for j=1:size(trainInput,1)
    if a(j)<0.5 ans=0; else ans=1; end
    if trainOutput(j)==ans corr=corr+1; end
end

fit=-corr/size(trainInput,1)*100+ALPHA*nc; % percent train accuracy as fitness

%note that the number of variables in GA are:
%Connections(input to hidden): hn*in
%Weights(input to hidden): hn*in
%Connections(hidden to output): hn*1
%Weights(hidden to output): hn*1
%Biases(hidden): hn
%Biases(output): 1

% Total: 2*hn*in+2*hn*1+hn+1
% all usually lie within -2 to 2